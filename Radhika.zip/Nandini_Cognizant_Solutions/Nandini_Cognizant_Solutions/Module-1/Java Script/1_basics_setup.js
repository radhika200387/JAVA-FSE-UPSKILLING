// JavaScript Basics & Setup
console.log("Welcome to the Community Portal");

window.onload = () => {
  alert("Page loaded successfully!");
};
